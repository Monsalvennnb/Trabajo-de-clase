# IDEM8-34
Pagina para proyecto transversal con las materias de sociales, ingles, matemáticas y tecnología.
[IDEM8-34-main.zip](https://github.com/cuscuz1/IDEM8-34/files/11212141/IDEM8-34-main.zip)
